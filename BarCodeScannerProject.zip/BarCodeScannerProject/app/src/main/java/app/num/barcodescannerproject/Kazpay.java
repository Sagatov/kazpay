package app.num.barcodescannerproject;

import android.app.AlertDialog;
import android.os.AsyncTask;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by Adik on 21.01.2017.
 */

public class Kazpay extends AsyncTask<String, String, String> {

    String code;
    String resp;
    HttpResponseHandler responseHandler;
    public Kazpay(String code, HttpResponseHandler responseHandler){
        this.code =code;
        this.responseHandler = responseHandler;
    }

    @Override
    protected String doInBackground(String[] objects) {
        resp = null;

        URL url = null;
        try {
            url = new URL("http://192.168.1.104:8081/request/print?code="+code);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) url.openConnection();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            con.setRequestMethod("GET");
        } catch (ProtocolException e) {
            e.printStackTrace();
        }
        con.setRequestProperty("User-Agent", "Mozilla/5.0");
        con.setRequestProperty("Accept-Charset", "UTF-8");
        Scanner in = null;
        try {
            in = new Scanner(con.getInputStream());
            resp = (in.hasNext())?in.next():"Dalbaebsyndar";
        } catch (IOException e) {
            e.printStackTrace();
        }


        return resp;
    }
    @Override
    protected void onPostExecute(String  params){
        responseHandler.handleHttpGetResponse(resp);
    }
}
