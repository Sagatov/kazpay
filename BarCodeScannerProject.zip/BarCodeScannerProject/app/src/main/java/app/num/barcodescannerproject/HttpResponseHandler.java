package app.num.barcodescannerproject;

/**
 * Created by Adik on 21.01.2017.
 */

public interface HttpResponseHandler {
    void handleHttpGetResponse(String resp);
}
